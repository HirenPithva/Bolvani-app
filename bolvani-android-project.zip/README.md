# બોલવાની પ્રેક્ટિસ – native Android app (Kotlin + Jetpack Compose)

Build the APK
1. Commit this whole folder to a GitHub repo on branch `main`.
2. GitHub → Actions → "Build Android APK" runs on every push (or press "Run workflow").
3. Open the finished run, download the artifact `bolvani-practice-apk`, unzip it, and install `app-debug.apk` on the phone (allow "Install unknown apps").

Using the app
- First launch: allow the microphone (needed for Auto mode).
- The phone needs the Google Gujarati text-to-speech voice. The app shows an install button if it is missing.
- Debug-signed APK: fine for direct install, not for the Play Store.

Open in Android Studio: File → Open this folder (it will offer to create the Gradle wrapper).
