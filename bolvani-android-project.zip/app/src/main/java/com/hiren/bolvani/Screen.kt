package com.hiren.bolvani

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card as M3Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Primary = Color(0xFF0B5CAD)
private val OkC = Color(0xFF0A6B2D)
private val Bad = Color(0xFFA50E0E)
private val Soft = Color(0xFFE8F0FA)
private val Cream = Color(0xFFFFFBF0)
private val Ink = Color(0xFF161616)
private val Edge = Color(0xFF1F3A5F)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Primary, background = Cream, surface = Color.White,
            onSurface = Ink, onBackground = Ink
        ),
        content = content
    )
}

@Composable
fun Btn(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
    color: Color = Primary,
    size: Int = 22
) {
    val shape = RoundedCornerShape(16.dp)
    val m = modifier.heightIn(min = 64.dp)
    if (filled) {
        Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = color)
        ) { Text(text, fontSize = size.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
    } else {
        OutlinedButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            border = BorderStroke(3.dp, if (enabled) color else Color.Gray),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = color)
        ) { Text(text, fontSize = size.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    M3Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(3.dp, Edge)
    ) {
        Column(Modifier.padding(16.dp).fillMaxWidth(), content = content)
    }
}

@Composable
private fun Lbl(t: String) =
    Text(t, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))

private fun openTtsInstall(ctx: Context) {
    try {
        ctx.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
}

@Composable
fun PracticeScreen(vm: PracticeViewModel) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Card?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        pending?.let { vm.start(it) }
        pending = null
    }

    fun begin(c: Card) {
        val noMic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        if (c.auto && c.word.isNotBlank() && noMic) {
            pending = c
            launcher.launch(Manifest.permission.RECORD_AUDIO)
        } else vm.start(c)
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).imePadding().fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Column {
                Text(
                    "🗣 બોલવાની પ્રેક્ટિસ", fontSize = 30.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "શબ્દ લખો, સાંભળો અને બોલો", fontSize = 20.sp, textAlign = TextAlign.Center,
                    color = Color(0xFF444444), modifier = Modifier.fillMaxWidth()
                )
            } }
            if (!vm.gujaratiVoice) item {
                Column(
                    Modifier.background(Color(0xFFFFF3CD), RoundedCornerShape(16.dp)).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "⚠ આ ફોનમાં ગુજરાતી અવાજ મળ્યો નથી. નીચેનું બટન દબાવી “Google ગુજરાતી” અવાજ ઇન્સ્ટોલ કરો, પછી “ફરી તપાસો” દબાવો.",
                        fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4A3500)
                    )
                    Btn("🔊 ગુજરાતી અવાજ ઇન્સ્ટોલ કરો", { openTtsInstall(ctx) }, Modifier.fillMaxWidth(), filled = true)
                    Btn("🔄 ફરી તપાસો", { vm.recheckVoice() }, Modifier.fillMaxWidth())
                }
            }
            item {
                Panel {
                    Lbl("બોલવાની ઝડપ")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf("🐢 ખૂબ ધીમું" to 0.3f, "ધીમું" to 0.45f, "સામાન્ય" to 0.7f).forEach { (n, v) ->
                            Btn(n, { vm.speed = v }, Modifier.weight(1f), filled = vm.speed == v, size = 18)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Lbl("અક્ષરે અક્ષર શીખવો")
                    Btn(
                        if (vm.letters) "હા, ચાલુ" else "ના, બંધ",
                        { vm.letters = !vm.letters }, Modifier.fillMaxWidth(), filled = vm.letters
                    )
                }
            }
            itemsIndexed(vm.cards, key = { _, c -> c.id }) { i, c ->
                CardView(c, i + 1, vm) { begin(it) }
            }
            item { Btn("➕ નવું ખાનું ઉમેરો", { vm.addCard() }, Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
private fun CardView(c: Card, number: Int, vm: PracticeViewModel, onStart: (Card) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("આ ખાનું કાઢી નાખવું છે?", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.removeCard(c) }) {
                    Text("હા, કાઢો", fontSize = 20.sp, color = Bad)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("ના", fontSize = 20.sp) } }
        )
    }
    Panel {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ખાનું $number", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Btn("✕ કાઢો", { confirm = true }, color = Bad, size = 16)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("🤖 ઓટો\nમશીન સાંભળશે", { c.auto = true }, Modifier.weight(1f), filled = c.auto, size = 18)
            Btn("🎛 મેન્યુઅલ\nજાતે ચલાવો", { c.auto = false }, Modifier.weight(1f), filled = !c.auto, size = 18)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = c.word, onValueChange = { c.word = it },
            modifier = Modifier.fillMaxWidth(),
            textStyle = TextStyle(fontSize = 32.sp),
            placeholder = { Text("અહીં શબ્દ કે અક્ષર લખો", fontSize = 20.sp) },
            singleLine = true, shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(8.dp))
        val bg = when (c.kind) { Kind.OK -> Color(0xFFDDF3E4); Kind.BAD -> Color(0xFFFBE0E0); else -> Soft }
        val fg = when (c.kind) { Kind.OK -> OkC; Kind.BAD -> Bad; else -> Ink }
        Box(
            Modifier.fillMaxWidth().heightIn(min = 56.dp).background(bg, RoundedCornerShape(12.dp)).padding(12.dp)
        ) { Text(c.status, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = fg) }
        Spacer(Modifier.height(12.dp))
        Btn(if (c.auto) "▶ શરૂ કરો" else "▶ સાંભળો", { onStart(c) }, Modifier.fillMaxWidth(), filled = true)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn(
                if (c.state == RunState.PAUSED) "▶ ચાલુ રાખો" else "⏸ થોભો",
                { if (c.state == RunState.PAUSED) vm.resume(c) else vm.pause(c) },
                Modifier.weight(1f), enabled = c.state != RunState.IDLE
            )
            Btn("⏹ બંધ કરો", { vm.stop(c) }, Modifier.weight(1f), enabled = c.state != RunState.IDLE, color = Bad)
        }
        if (!c.auto) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("⏮ પાછળ", { vm.seek(c, -1) }, Modifier.weight(1f), enabled = c.state != RunState.IDLE)
                Btn("⏭ આગળ", { vm.seek(c, 1) }, Modifier.weight(1f), enabled = c.state != RunState.IDLE)
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp).clickable { c.repeat = !c.repeat },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = c.repeat, onCheckedChange = { c.repeat = it })
                Text("વારંવાર સંભળાવો (ફરી ફરી)", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
