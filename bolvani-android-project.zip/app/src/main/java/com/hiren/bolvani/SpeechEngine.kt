package com.hiren.bolvani

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.content.Intent
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

enum class Heard { MATCH, NO_MATCH, DENIED }

class SpeechEngine(private val ctx: Context, private val onVoice: (Boolean) -> Unit) {
    private var tts: TextToSpeech? = null
    private var counter = 0
    @Volatile private var initDone = false
    private val gu: Locale = Locale.forLanguageTag("gu-IN")

    init {
        create("com.google.android.tts") // best Gujarati quality; falls back to default engine
    }

    private fun create(engine: String?) {
        tts = TextToSpeech(ctx, TextToSpeech.OnInitListener { status ->
            if (status != TextToSpeech.SUCCESS && engine != null) {
                create(null)
                return@OnInitListener
            }
            initDone = true
            onVoice(status == TextToSpeech.SUCCESS && voiceAvailable())
        }, engine)
    }

    private fun voiceAvailable(): Boolean {
        val r = tts?.setLanguage(gu) ?: TextToSpeech.LANG_NOT_SUPPORTED
        return r >= TextToSpeech.LANG_AVAILABLE
    }

    fun recheckVoice() = onVoice(voiceAvailable())

    fun recognitionAvailable() = SpeechRecognizer.isRecognitionAvailable(ctx)

    suspend fun speak(text: String, rate: Float) {
        var waited = 0
        while (!initDone && waited < 3000) { delay(100); waited += 100 }
        suspendCancellableCoroutine<Unit> { cont ->
            val t = tts
            if (t == null) { cont.resume(Unit); return@suspendCancellableCoroutine }
            val id = "u${++counter}"
            t.setSpeechRate(rate)
            t.setPitch(1.0f)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(Unit)
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(Unit)
                }
            })
            cont.invokeOnCancellation { t.stop() }
            val res = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            if (res == TextToSpeech.ERROR && cont.isActive) cont.resume(Unit)
        }
    }

    /** Listens once (call from the main thread). */
    suspend fun listen(timeoutMs: Long, isMatch: (String) -> Boolean): Heard =
        suspendCancellableCoroutine { cont ->
            val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
            val handler = Handler(Looper.getMainLooper())
            var finished = false

            fun finish(o: Heard) {
                if (finished) return
                finished = true
                handler.removeCallbacksAndMessages(null)
                try { sr.destroy() } catch (_: Exception) {}
                if (cont.isActive) cont.resume(o)
            }

            fun outcome(b: Bundle?): Heard {
                val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                return if (list.any(isMatch)) Heard.MATCH else Heard.NO_MATCH
            }

            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    finish(
                        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) Heard.DENIED
                        else Heard.NO_MATCH
                    )
                }
                override fun onResults(results: Bundle?) = finish(outcome(results))
                override fun onPartialResults(partialResults: Bundle?) {
                    if (outcome(partialResults) == Heard.MATCH) finish(Heard.MATCH)
                }
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "gu-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            }
            handler.postDelayed({ finish(Heard.NO_MATCH) }, timeoutMs)
            cont.invokeOnCancellation { finish(Heard.NO_MATCH) }
            sr.startListening(intent)
        }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
