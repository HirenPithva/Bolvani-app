package com.hiren.bolvani

import android.icu.text.BreakIterator
import java.util.Locale

object Matcher {
    private val strip = Regex("[\\s\\p{P}]")

    private fun norm(s: String) = s.lowercase().replace(strip, "")

    private fun lev(a: String, b: String): Int {
        val m = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = m[0]
            m[0] = i
            for (j in 1..b.length) {
                val tmp = m[j]
                m[j] = minOf(m[j] + 1, m[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return m[b.length]
    }

    /** True if what the microphone heard is (close to) the practice word. */
    fun ok(heard: String, word: String): Boolean {
        val h = norm(heard)
        val w = norm(word)
        if (h.isEmpty() || w.isEmpty()) return false
        if (h.contains(w)) return true
        return 1.0 - lev(h, w).toDouble() / maxOf(h.length, w.length) >= 0.7
    }

    /** Splits text into user-perceived letters (consonant + vowel sign stay together). */
    fun graphemes(s: String): List<String> {
        val iter = BreakIterator.getCharacterInstance(Locale.forLanguageTag("gu"))
        iter.setText(s)
        val out = mutableListOf<String>()
        var start = iter.first()
        var end = iter.next()
        while (end != BreakIterator.DONE) {
            out.add(s.substring(start, end))
            start = end
            end = iter.next()
        }
        // Older ICU versions split Gujarati conjuncts after the virama; glue them back.
        val merged = mutableListOf<String>()
        var carry = ""
        for (g in out.filter { it.isNotBlank() }) {
            val cur = carry + g
            if (cur.endsWith("\u0ACD")) carry = cur else { merged.add(cur); carry = "" }
        }
        if (carry.isNotEmpty()) merged.add(carry)
        return merged
    }
}
