package com.hiren.bolvani

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class RunState { IDLE, PLAYING, PAUSED }
enum class Kind { INFO, OK, BAD }
data class Step(val text: String, val waitMs: Long)

class Card(val id: Int) {
    var word by mutableStateOf("")
    var status by mutableStateOf("")
    var kind by mutableStateOf(Kind.INFO)
    var state by mutableStateOf(RunState.IDLE)
    var repeat by mutableStateOf(false)
    var auto by mutableStateOf(true)
    var attempt = 0
    var steps: List<Step> = emptyList()
    var idx = 0
    var spoken = ""
    var job: Job? = null

    fun say(t: String, k: Kind = Kind.INFO) { status = t; kind = k }
}

class PracticeViewModel(app: Application) : AndroidViewModel(app) {
    val cards = mutableStateListOf<Card>()
    var speed by mutableStateOf(0.45f)
    var letters by mutableStateOf(true)
    var gujaratiVoice by mutableStateOf(true)

    private var nextId = 1
    private val engine = SpeechEngine(app) { ok -> gujaratiVoice = ok }

    init { addCard(); addCard() }

    fun addCard() { if (cards.size < 10) cards.add(Card(nextId++)) }

    fun removeCard(c: Card) {
        if (cards.size < 2) { c.say("ઓછામાં ઓછું એક ખાનું જરૂરી છે", Kind.BAD); return }
        c.job?.cancel()
        cards.remove(c)
    }

    fun recheckVoice() = engine.recheckVoice()

    private fun buildSteps(w: String): List<Step> {
        val s = mutableListOf(Step(w, 1500))
        val g = Matcher.graphemes(w)
        if (letters && g.size > 1) {
            g.forEach { s.add(Step(it, 1000)) }
            s.add(Step(w, 1500))
        }
        return s
    }

    private fun stopOthers(except: Card) {
        cards.filter { it !== except && it.state != RunState.IDLE }.forEach {
            it.job?.cancel(); it.state = RunState.IDLE; it.idx = 0; it.say("")
        }
    }

    fun start(c: Card) {
        val w = c.word.trim()
        if (w.isEmpty()) { c.say("✍ કૃપા કરી પહેલા શબ્દ કે અક્ષર લખો", Kind.BAD); return }
        stopOthers(c)
        c.spoken = w
        c.steps = buildSteps(w)
        c.idx = 0
        c.attempt = 0
        run(c)
    }

    fun seek(c: Card, delta: Int) {
        if (c.steps.isEmpty()) return
        val cur = minOf(c.idx, c.steps.size - 1)
        c.idx = (cur + delta).coerceIn(0, c.steps.size - 1)
        stopOthers(c)
        run(c)
    }

    fun resume(c: Card) { stopOthers(c); run(c) }

    fun pause(c: Card) { c.job?.cancel(); c.state = RunState.PAUSED; c.say("⏸ થોભાવ્યું") }

    fun stop(c: Card) { c.job?.cancel(); c.state = RunState.IDLE; c.idx = 0; c.say("⏹ બંધ કર્યું") }

    private fun run(c: Card) {
        c.job?.cancel()
        c.state = RunState.PLAYING
        c.job = viewModelScope.launch {
            while (true) {
                while (c.idx < c.steps.size) {
                    val s = c.steps[c.idx]
                    c.say("🔊 સાંભળો: ${s.text}")
                    engine.speak(s.text, speed)
                    delay(s.waitMs)
                    c.idx++
                }
                if (c.auto) {
                    if (!engine.recognitionAvailable()) {
                        c.say("⚠ આ ફોનમાં બોલેલું સાંભળવાની સુવિધા નથી. મેન્યુઅલ રીત વાપરો.", Kind.BAD)
                        break
                    }
                    c.attempt++
                    c.say("🎤 હવે તમે બોલો… (પ્રયત્ન ${c.attempt})")
                    val t0 = SystemClock.elapsedRealtime()
                    when (engine.listen(LISTEN_MS) { Matcher.ok(it, c.spoken) }) {
                        Heard.MATCH -> {
                            c.say("🎉 શાબાશ! તમે બરાબર બોલ્યા", Kind.OK)
                            engine.speak("શાબાશ", 0.6f)
                            break
                        }
                        Heard.DENIED -> {
                            c.say("⚠ માઇક્રોફોનની મંજૂરી આપો, પછી ફરી શરૂ કરો.", Kind.BAD)
                            break
                        }
                        Heard.NO_MATCH -> {}
                    }
                    val left = LISTEN_MS - (SystemClock.elapsedRealtime() - t0)
                    if (left > 0) delay(left) // always give the full time to speak
                    c.say("🔁 ફરી એકવાર સાંભળીએ…")
                    delay(1200)
                    c.idx = 0
                } else if (c.repeat) {
                    delay(2000)
                    c.idx = 0
                } else {
                    c.say("✅ પૂરું થયું")
                    break
                }
            }
            c.state = RunState.IDLE
            c.idx = 0
        }
    }

    override fun onCleared() {
        cards.forEach { it.job?.cancel() }
        engine.shutdown()
    }

    private companion object { const val LISTEN_MS = 9000L }
}
